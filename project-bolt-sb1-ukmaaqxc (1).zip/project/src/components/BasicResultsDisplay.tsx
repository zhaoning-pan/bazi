import React from 'react';
import { motion } from 'framer-motion';
import { FormData } from './BirthDateForm';
import { Calendar, Clock, MapPin, Star, Moon, Flame, Droplets, Compass, Sparkles } from 'lucide-react';

interface BasicResultsDisplayProps {
  formData: FormData;
}

const BasicResultsDisplay: React.FC<BasicResultsDisplayProps> = ({ formData }) => {
  // Sample data - in a real app, this would be calculated based on the form data
  const birthYear = new Date(formData.birthDate).getFullYear();
  
  const getChineseZodiac = (year: number) => {
    const animals = ['Rat', 'Ox', 'Tiger', 'Rabbit', 'Dragon', 'Snake', 'Horse', 'Goat', 'Monkey', 'Rooster', 'Dog', 'Pig'];
    return animals[(year - 4) % 12];
  };
  
  const zodiac = getChineseZodiac(birthYear);
  
  // Mock elements based on birth year - in a real app, this would be calculated
  const elements = [
    { name: 'Wood', strength: 'Strong', icon: <Droplets className="h-5 w-5" />, color: 'text-green-500' },
    { name: 'Fire', strength: 'Weak', icon: <Flame className="h-5 w-5" />, color: 'text-red-500' },
    { name: 'Earth', strength: 'Balanced', icon: <Compass className="h-5 w-5" />, color: 'text-amber-500' },
    { name: 'Metal', strength: 'Strong', icon: <Sparkles className="h-5 w-5" />, color: 'text-gray-400' },
    { name: 'Water', strength: 'Balanced', icon: <Droplets className="h-5 w-5" />, color: 'text-blue-500' }
  ];
  
  // Mock reading insights - in a real app, these would be generated based on calculations
  const insights = [
    "Your chart shows a strong Wood element, indicating creativity and growth potential.",
    "There's a challenge between your Water and Fire elements that may create internal conflict.",
    "Your birth time reveals a favorable influence from the Fortune Star in your career palace.",
    "The current year's energy aligns well with your natural strengths."
  ];
  
  // Mock guidance - in a real app, these would be generated based on calculations
  const guidance = [
    "Focus on building relationships with mentors who can guide your professional growth.",
    "Avoid making major financial decisions during the upcoming summer months.",
    "Your communication skills are highlighted - consider ways to leverage them in your career.",
    "Practice patience in close relationships as there may be temporary tensions."
  ];

  return (
    <div className="mb-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-indigo-900 bg-opacity-30 backdrop-blur-sm rounded-2xl border border-indigo-800 p-6 md:p-8 mb-8"
      >
        <h2 className="text-2xl font-serif text-white mb-6 text-center">
          Your Basic Reading Results
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-indigo-950 bg-opacity-70 p-4 rounded-xl">
            <h3 className="text-lg text-amber-400 mb-4">Your Birth Information</h3>
            <div className="space-y-3">
              <div className="flex items-center">
                <Calendar className="h-5 w-5 text-slate-400 mr-3" />
                <span className="text-slate-300">Date: {new Date(formData.birthDate).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-slate-400 mr-3" />
                <span className="text-slate-300">Time: {formData.birthTime}</span>
              </div>
              <div className="flex items-center">
                <MapPin className="h-5 w-5 text-slate-400 mr-3" />
                <span className="text-slate-300">Place: {formData.birthPlace}</span>
              </div>
            </div>
          </div>
          
          <div className="bg-indigo-950 bg-opacity-70 p-4 rounded-xl">
            <h3 className="text-lg text-amber-400 mb-4">Your Chinese Zodiac</h3>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="bg-amber-500 bg-opacity-20 p-3 rounded-full mr-4">
                  <Star className="h-6 w-6 text-amber-500" />
                </div>
                <div>
                  <span className="block text-white text-xl">{zodiac}</span>
                  <span className="text-slate-400 text-sm">Born in {birthYear}</span>
                </div>
              </div>
              <img 
                src={`https://images.pexels.com/photos/4064432/pexels-photo-4064432.jpeg?auto=compress&cs=tinysrgb&w=150`}
                alt={zodiac} 
                className="w-16 h-16 rounded-full border-2 border-amber-500"
              />
            </div>
          </div>
        </div>
        
        <div className="bg-indigo-950 bg-opacity-70 p-4 rounded-xl mb-8">
          <h3 className="text-lg text-amber-400 mb-4">Your Five Elements</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {elements.map((element, index) => (
              <div key={index} className="bg-indigo-900 bg-opacity-50 p-3 rounded-lg text-center">
                <div className={`flex items-center justify-center ${element.color} mb-2`}>
                  {element.icon}
                  <span className="ml-1 font-medium">{element.name}</span>
                </div>
                <span className="text-sm text-slate-300">{element.strength}</span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-indigo-950 bg-opacity-70 p-4 rounded-xl">
            <h3 className="text-lg text-amber-400 mb-4">Key Insights</h3>
            <ul className="space-y-3">
              {insights.map((insight, index) => (
                <li key={index} className="flex items-start">
                  <Star className="h-5 w-5 text-amber-500 mr-3 flex-shrink-0 mt-0.5" />
                  <span className="text-slate-300">{insight}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="bg-indigo-950 bg-opacity-70 p-4 rounded-xl">
            <h3 className="text-lg text-amber-400 mb-4">Guidance for You</h3>
            <ul className="space-y-3">
              {guidance.map((tip, index) => (
                <li key={index} className="flex items-start">
                  <Moon className="h-5 w-5 text-blue-400 mr-3 flex-shrink-0 mt-0.5" />
                  <span className="text-slate-300">{tip}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="mt-8 text-center text-slate-300">
          <p>This is just a basic overview of your celestial blueprint.</p>
          <p>For a detailed analysis, consider our premium readings below.</p>
        </div>
      </motion.div>
    </div>
  );
};

export default BasicResultsDisplay;