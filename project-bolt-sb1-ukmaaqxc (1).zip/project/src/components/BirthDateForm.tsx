import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CalendarClock, Info } from 'lucide-react';

export interface FormData {
  name: string;
  gender: string;
  birthDate: string;
  birthTime: string;
  birthPlace: string;
  email: string;
}

interface BirthDateFormProps {
  onSubmit: (data: FormData) => void;
}

const BirthDateForm: React.FC<BirthDateFormProps> = ({ onSubmit }) => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    gender: '',
    birthDate: '',
    birthTime: '',
    birthPlace: '',
    email: ''
  });

  const [errors, setErrors] = useState<Partial<FormData>>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when field is edited
    if (errors[name as keyof FormData]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<FormData> = {};
    
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.gender) newErrors.gender = 'Gender is required';
    if (!formData.birthDate) newErrors.birthDate = 'Birth date is required';
    if (!formData.birthTime) newErrors.birthTime = 'Birth time is required for accurate readings';
    if (!formData.birthPlace.trim()) newErrors.birthPlace = 'Birth place is required';
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email is invalid';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="bg-indigo-900 bg-opacity-30 backdrop-blur-sm rounded-2xl border border-indigo-800 p-6 md:p-8 max-w-2xl mx-auto"
    >
      <div className="flex items-center mb-6">
        <div className="bg-amber-500 p-3 rounded-full mr-4">
          <CalendarClock className="h-6 w-6 text-white" />
        </div>
        <h2 className="text-2xl font-medium text-white">Enter Your Birth Information</h2>
      </div>
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <label htmlFor="name" className="block text-slate-200 mb-2">Full Name</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              className={`w-full bg-indigo-950 border ${errors.name ? 'border-red-500' : 'border-indigo-700'} rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-amber-500`}
              placeholder="Enter your full name"
            />
            {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
          </div>
          
          <div>
            <label htmlFor="gender" className="block text-slate-200 mb-2">Gender</label>
            <select
              id="gender"
              name="gender"
              value={formData.gender}
              onChange={handleChange}
              className={`w-full bg-indigo-950 border ${errors.gender ? 'border-red-500' : 'border-indigo-700'} rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-amber-500`}
            >
              <option value="">Select gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
            {errors.gender && <p className="text-red-500 text-sm mt-1">{errors.gender}</p>}
          </div>
          
          <div>
            <label htmlFor="birthDate" className="block text-slate-200 mb-2">Birth Date</label>
            <input
              type="date"
              id="birthDate"
              name="birthDate"
              value={formData.birthDate}
              onChange={handleChange}
              className={`w-full bg-indigo-950 border ${errors.birthDate ? 'border-red-500' : 'border-indigo-700'} rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-amber-500`}
            />
            {errors.birthDate && <p className="text-red-500 text-sm mt-1">{errors.birthDate}</p>}
          </div>
          
          <div>
            <label htmlFor="birthTime" className="block text-slate-200 mb-2">Birth Time</label>
            <input
              type="time"
              id="birthTime"
              name="birthTime"
              value={formData.birthTime}
              onChange={handleChange}
              className={`w-full bg-indigo-950 border ${errors.birthTime ? 'border-red-500' : 'border-indigo-700'} rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-amber-500`}
            />
            {errors.birthTime && <p className="text-red-500 text-sm mt-1">{errors.birthTime}</p>}
          </div>
          
          <div>
            <label htmlFor="birthPlace" className="block text-slate-200 mb-2">Birth Place</label>
            <input
              type="text"
              id="birthPlace"
              name="birthPlace"
              value={formData.birthPlace}
              onChange={handleChange}
              className={`w-full bg-indigo-950 border ${errors.birthPlace ? 'border-red-500' : 'border-indigo-700'} rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-amber-500`}
              placeholder="City, Country"
            />
            {errors.birthPlace && <p className="text-red-500 text-sm mt-1">{errors.birthPlace}</p>}
          </div>
          
          <div>
            <label htmlFor="email" className="block text-slate-200 mb-2">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className={`w-full bg-indigo-950 border ${errors.email ? 'border-red-500' : 'border-indigo-700'} rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-amber-500`}
              placeholder="For receiving your reading"
            />
            {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
          </div>
        </div>
        
        <div className="bg-indigo-950 bg-opacity-70 p-4 rounded-lg mb-6 flex items-start">
          <Info className="h-5 w-5 text-amber-400 mr-3 flex-shrink-0 mt-0.5" />
          <p className="text-slate-300 text-sm">
            For the most accurate reading, please provide your exact birth time. The time of birth plays a crucial role in both BaZi and Zi Wei Dou Shu calculations.
          </p>
        </div>
        
        <button
          type="submit"
          className="w-full bg-gradient-to-r from-amber-500 to-red-600 text-white py-3 rounded-lg font-medium text-lg transition-all duration-300 hover:shadow-lg hover:shadow-amber-500/20"
        >
          Get Your Reading
        </button>
      </form>
    </motion.div>
  );
};

export default BirthDateForm;